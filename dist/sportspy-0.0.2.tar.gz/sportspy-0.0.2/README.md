# Sportspy

Are You Prepared to Meet The Next Level of Competition? 
The various approach to demystify the data is to quantify it appropriately through key performance indicator could be stated as sports and performance metrics; that differs from sports to sports and body to body. When soever a player is participating in various training or events there is a roll-out of lots of data in two forms human body performance and sports specific data.
“The objectives of sports science data scientist is not only to look after match day metrics but also the bodily changes that may cause an impact of the performance.”
With context to human performance and sports analyst, in the first version:
1. Anthropometry
2. Load Monitoring

version="0.0.2"
   
## Installation

pip install sportspy

## Usage

It will be going to help sports statisticians or sports analysts and even though sports scientists analyze the team or individual athlete in terms of their fitness and performance.

## Contributing

Author :Swetank Pathak

Author_email : swetankpathak@gmail.com


## License

Copyright (c) 2021 Swetank Pathak

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.